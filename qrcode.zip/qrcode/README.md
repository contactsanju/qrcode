## QR Code Generator Website💻 using Flask🐍🐍
This webapp created on Flask which can convert any word into QR Code

### Sourcerer
<a href="https://sourcerer.io/spidy20"><img src="https://avatars2.githubusercontent.com/u/42056100?v=4" height="50px" width="50px" alt=""/></a>

### Code Requirements
- Flask(`pip install flask`)
- pyqrcode(`pip install pyqrcode`)
- pypng(`pip install pypng`)



### What steps you have to follow??

- Run `app.py`
- Go to ` http://127.0.0.1:5000/QR_Code_Generater `

### Screenshots

### (1)
<img src="https://github.com/Spidy20/QR_Code_website_Flask/blob/master/Screenshot (7).png">


### (2)
<img src="https://github.com/Spidy20/QR_Code_website_Flask/blob/master/Screenshot (8).png">

